<?php
/*
 * This page shows user wishlist
 * 
 */
$GeneralThemeObject = new GeneralTheme();
$WishlistObject = new classWishList();
$GeneralThemeObject->authentic();
$userDetails = $GeneralThemeObject->user_details();
$getLandingCity = $GeneralThemeObject->getLandingCity();
$getUserWishlist = $WishlistObject->getWishListItems($userDetails->data['user_id']);
?>
<div class="right mobile-view">
    <div class="">
        <?php if (is_array($getUserWishlist) && count($getUserWishlist) > 0) : ?>
            <?php foreach ($getUserWishlist as $eachWishList) : ?>
                <?php
                $productDetails = $GeneralThemeObject->product_details($eachWishList->product_id);
                $productImg = wp_get_attachment_image_src($productDetails->data['thumbnail_id'], 'full');
                $productState = get_term_by('id', $eachWishList->state, themeFramework::$theme_prefix . 'product_city');
                $productCity = get_term_by('id', $eachWishList->city, themeFramework::$theme_prefix . 'product_city');
                ?>
                <div class="mobile-wishlist">
                    <div class="cart-details">
                        <div class="col-sm-3 col-xs-4 no-padding">
                            <a href="<?php echo get_permalink($eachWishList->product_id); ?>">
                                <img src="<?php echo ($productImg[0]) ? $productImg[0] : 'https://via.placeholder.com/100x75'; ?>" width="100" height="75" alt="<?php echo $productDetails->data['title']; ?>"/>
                            </a>
                        </div>
                        <div class="col-sm-9 col-xs-8 product-name">
                            <a href="<?php echo get_permalink($eachWishList->product_id); ?>">
                                <?php echo $productDetails->data['title']; ?>
                            </a>
                            <div><?php echo $productState->name; ?></div>
                            <div><?php echo $productCity->name; ?></div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="cart-details">
                        <div class="col-sm-6 col-xs-6">
                            <span class="price"><?php echo $productDetails->data['price']; ?></span>
                        </div>
                        <div class="col-sm-6 col-xs-6 text-right">
                            <a href="javascript:void(0);" class="add-to-cart btn round cart" title="<?php _e('Add to cart', THEME_TEXTDOMAIN); ?>" data-state="<?php echo base64_encode($eachWishList->state); ?>" data-city="<?php echo base64_encode($eachWishList->city); ?>" data-pro="<?php echo base64_encode($eachWishList->product_id); ?>"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a>
                            <a href="javascript:void(0);" class="remove-from-wishlist btn round del" title="<?php _e('Remove from wishlist', THEME_TEXTDOMAIN); ?>" data-state="<?php echo base64_encode($eachWishList->state); ?>" data-city="<?php echo base64_encode($eachWishList->city); ?>" data-pro="<?php echo base64_encode($eachWishList->product_id); ?>"><i class="fa fa-trash" aria-hidden="true"></i></a>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="mobile-wishlist">
                <div class="cart-details">
                    <div class="col-sm-12 col-xs-12">
                        <div class="alert alert-danger"><?php _e('No items in your wishlist now.', THEME_TEXTDOMAIN); ?></div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>




<?php

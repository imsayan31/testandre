<?php
/*
 * Template Name: User Material List template
 * 
 */
get_header('printable');
?>
<div class="container">
    <?php theme_template_part('user-material-list/user-material-list'); ?>
</div>
<?php
get_footer('printable');

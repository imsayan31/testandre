jQuery(document).ready(function ($) {
    /*$('.attribute_city').on('change', function (event) {
        var trHTML = '<div class="form-field new-var-price">';
        trHTML += '<input type="text" name="attribute_var_price[]" id="attribute_var_price" size="25" style="width:60%;" placeholder="City price*" value=""><a href="javascript:void(0);" class="delete-attr-price">remove</a><br>';
        trHTML += '</div>';
        $('.new-var-price').last().after(trHTML);*/
        /*var target = $(event.target), priorDataSet = target.data("chosen-values"), currentDataSet = target.val();
         target.data("chosen-values", currentDataSet);
         if (priorDataSet && currentDataSet) {
         if (priorDataSet.length > currentDataSet.length) {
         
         }
         }*/

    //});
    /*$(document.body).on('click', '.delete-attr-price', function () {
        $(this).parent('div.new-var-price').remove();
    });*/
});
jQuery(document).ready(function ($) {
    
});